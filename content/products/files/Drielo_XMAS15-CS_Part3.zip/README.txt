DRIELO — 15 Mini Christmas Cross Stitch Patterns

This bundle contains 15 individual PDF cross stitch patterns.
Each PDF includes colour charts, black-and-white symbol charts, DMC colour information and finished-design previews.

Digital patterns only. No physical materials are included.
Personal use only. Please do not resell, redistribute or share the digital files.
